<?php

$username = "root";
$password = "";
$server = 'localhost';
$db = 'id_card_generator';
$con =mysqli_connect($server,$username,$password,$db);

if(!$con){
    ?>
    <script>
        alert("Not Connected");
     </script>  
     <?php 
}

?>




