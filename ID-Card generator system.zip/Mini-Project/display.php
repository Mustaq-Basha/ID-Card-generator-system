

<!DOCTYPE html>
<html>
    <head>
      <?php include 'links.php';?>
      <style>
        table{
            border-collapse:collapse;
            background-color:#fff;
            box-shadow:0 10px 20px 0 rgba(0,0,0,0.3);
            border-radius:10px;
            margin:auto;
        }
        th,td{
            border:1px solid #f2f2f2;
            padding:8px 30px;
            text-align:center;
            color:grey;
        }
        th{
            text-transform: uppercase;
            font-weight: 500;
        }
        td{
            font-size:13px;
        }
        .fa-edit{ color:#63c76a;}
        .fa-trash{ color:#ff0000;}
      </style>
    </head>
    <body >
       <h1><center>Student List</center></h1>
       <center><div>
            <div class="table-responsive">
                <table>
                    <form  class="form-group" method="POST">
                        <div class="row">
                           <div class="col-md-10" ><input type="text" name="search" >
                           <input type="submit" name="submit"value="Search"></div>
                           
                        </div>
                    </form>
                    
                    <?php

                    if(isset($_POST["submit"]))
                        {
                            include 'connect.php';

                            $str = $_POST["search"];
                            $searchquery ="select * from student where id =$str";
                            $qul =mysqli_query($con,$searchquery);
                          
                            while($res =mysqli_fetch_assoc($qul)){
                                ?>
                                <tr>
                                   <td><?php echo $res['id'];?></td>
                                   <td><?php echo $res['name'];?></td>
                                   <td><?php echo $res['f_name'] ?></td>
                                   <td><?php echo $res['m_name'] ?></td>
                                   <td><?php echo $res['gender'] ?></td>
                                   <td><?php echo $res['dob'] ?></td>
                                   <td><?php echo $res['email'] ?></td>
                                   <td><?php echo $res['year'] ?></td>
                                   <td><?php echo $res['dept'] ?></td>
                                   <td><?php echo $res['mobile_no'] ?></td>
                                   <td><img src="assets/<?php echo $res['Image'] ?>" height="100px" width="100px"></td>
                                   <td><?php echo $res['state'] ?></td>
                                   <td><?php echo $res['city'] ?></td>
                                   <td><?php echo $res['zipcode'] ?></td>
                                   <td><a href="http://localhost/Mini-Project/updates.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></th>
                                   <td><a href="http://localhost/Mini-Project/delete.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></th>               
                               </tr>
                                 
                           <?php }

                        }
       
                           ?>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Father Name</th>
                            <th>Mother Name</th>
                            <th>Gender</th>
                            <th>DOB</th>
                            <th>Email</th>
                            <th>Semester</th>
                            <th>Dept</th>
                            <th>Mobile</th>
                            <th>Image</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Zip code</th>
                            
                            <th>Operation</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php
                        if(!isset($_POST["search"]))
                        {
                       
                        include 'connect.php';
                        $selectquery = "select * from student ";

                        $query = mysqli_query($con,$selectquery);

                        $num =mysqli_num_rows($query);

                        $res =mysqli_fetch_array($query);

                         while($res =mysqli_fetch_array($query)){
                         ?>
                            <tr>
                            <td><?php echo $res['id'];?></td>
                            <td><?php echo $res['name'];?></td>
                            <td><?php echo $res['f_name'] ?></td>
                            <td><?php echo $res['m_name'] ?></td>
                            <td><?php echo $res['gender'] ?></td>
                            <td><?php echo $res['dob'] ?></td>
                            <td><?php echo $res['email'] ?></td>
                            <td><?php echo $res['year'] ?></td>
                            <td><?php echo $res['dept'] ?></td>
                            <td><?php echo $res['mobile_no'] ?></td>
                            <td><img src="assets/<?php echo $res['Image'] ?>" height="100px" width="100px"></td>
                            <td><?php echo $res['state'] ?></td>
                            <td><?php echo $res['city'] ?></td>
                            <td><?php echo $res['zipcode'] ?></td>
                            <td><a href="http://localhost/Mini-Project/updates.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></th>
                            <td><a href="http://localhost/Mini-Project/delete.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></th>               
                        </tr>
                          
                    <?php }

                        }?>

                        
                    </tbody>
                </table>
            </div>

       </div>
    </center>
    <script>
     $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
    </body>
</html>