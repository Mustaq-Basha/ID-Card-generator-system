<?php 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Form</title>
    <style>
        
        html {
            background: rgba(233, 225, 225, 0.479);
        }
        
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: auto;
            width: 75vw;
            background: yellow;
            padding: 25px;
        }
        
        .container h1 {
            font-family: Arial, Helvetica, sans-serif;
            color: rgb(59, 55, 55);
            font-size: 25px;
            margin-bottom: 5px;
        }
        
        .container h2 {
            font-family: Arial, Helvetica, sans-serif;
            color: rgb(59, 55, 55);
            font-size: 20px;
            margin-top: 5px;
        }
        
        .form-wrapper {
            margin: 15px;
            width: 100%;
        }
        
        .form {
            width: 90%;
        }
        
        #studentimage {
            height: 80px;
            width: 80px;
            border-radius: 5px;
            font-family: Arial, Helvetica, sans-serif;
            color: rgb(59, 55, 55);
        }
        
        p {
            font-family: Arial, Helvetica, sans-serif;
            color: Black;
            font-size: 14px;
        }
        
        .form-item {
            display: flex;
            margin: auto;
            align-items: center;
            width: 80%;
        }
        
        .form-item label {
            width: 150px;
            font-size: 14px;
            font-family: Arial, Helvetica, sans-serif;
        }
        
        .form-item input {
            margin: 5px 15px;
            height: 22px;
            width: 100%;
            font-size: 13px;
            border: 1px black solid;
            border-radius: 5px;
        }
        
        .form-item select {
            margin: 5px 0px;
            width: max-content;
        }
        
        .genders {
            display: flex;
            align-items: center;
            font-family: Arial, Helvetica, sans-serif;
            margin-left: 16px;
            font-size: 14px;
        }
        
        .genders input {
            width: 20px;
        }
        
        hr {
            margin-top: 15px;
            width: 80%;
        }
        
        h3 {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
        .same-perm{
            display: flex;
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
            font-size: 13px;
            margin: 5px 105px;
        }
        
        .register {
            margin: 25px;
            background: #1e90ff;
            font-size: 20px;
            font-family: Arial, Helvetica, sans-serif;
            padding: 7px 20px;
            border-radius: 5px;
            color: whitesmoke;
            border: 0;
            cursor: pointer;
        }
        
        .register:hover {
            color: #3a3636;
        }
        
        #display_image{
            width:100px;
            height:100px;
            border:1px solid black;
            background-position: center;
            background-size: cover;
        }
        @media screen and (max-width: 640px) {
            .container {
                width: 90vw;
                padding: 10px 5px;
            }
            .form-item label {
                font-size: 14px;
            }
            .form-item input {
                margin: 5px 10px;
                font-size: 12px;
            }
            .genders {
                margin-left: 10px;
                font-size: 13px;
            }
            .genders input {
                width: 15px;
            }
            .same-perm{

            font-size: 13px;
            margin: 5px 50px;
        }
            .register {
                margin: 25px;
                font-size: 15px;
                padding: 7px 10px;
            }
        }
    

    </style>
    
</head>

<body>
    <div class="container">
        <h1>Dyananda Sagar Colege of Engineering</h1>
        <h2>Student Registration From</h2>
        <div class="form-wrapper">
            <form action="" method="POST">

            <?php 
 include 'connect.php'; 
 include 'links.php';

 $ids=$_GET['id'];
 $showquery="select * from student where id={$ids}";
 $showdata=mysqli_query($con,$showquery);
 $arrdata=mysqli_fetch_array($showdata);
 
 if(isset($_POST['Register'])){
   
    $name=$_POST['name'];
    $fname=$_POST['fname'];
    $mname=$_POST['mname'];
    $gender=$_POST['gender'];
    $DOB=$_POST['DOB'];
    $email=$_POST['email'];
    $year=$_POST['year'];
    $department=$_POST['department'];
    $phonenumber=$_POST['phonenumber'];
    $studentimage=$_POST['studentimage'];
    $pstate=$_POST['pstate'];
    $pcity=$_POST['pcity'];
    $pzip=$_POST['pzip'];
   

    $insertquery = "insert into student(id, name, f_name, m_name, gender, dob, email, year, dept, mobile_no, Image,state, city, zipcode) values('','$name','$fname','$mname','$gender','$DOB','$email','$year','$department','$phonenumber','$studentimage','$pstate','$pcity','$pzip')";

 
    $res=  mysqli_query($con,$insertquery);
    if($res){
        ?>
        <script>
            alert("Data inserted")
        </script>
        <?php
    }
    else{
        ?>
        <script>
            alert("Data  not inserted")
        </script>
        <?php
    }
}
?>
                <div class="form-item">
                    <label for="fullname">Student Name:</label>
                    <input type="text" name="name" id="fullname" placeholder="Full Name" value="<?php echo $arrdata['name'];?>" required>
                </div>
                <div class="form-item">
                    <label for="username">Father's Name:</label>
                    <input type="text" name="fname" id="fathersname" placeholder="Father's Full Name" value="<?php echo $arrdata['f_name'];?>" required>
                </div>
                <div class="form-item">
                    <label for="username" >Mother's Name:</label>
                    <input type="text" name="mname" id="mothersname" placeholder="Mother's Full Name" value="<?php echo $arrdata['m_name'];?>" required>
                </div>

                <div class="form-item">
                    <label for="gender">Gender:</label>
                    <select name="gender" id="gender" value="<?php echo $arrdata['gender'];?>">
                        <option value="male" >Male</option>
                        <option value="female">Female </option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-item">
                    <label>Date of Birth</label>
                    <input type="date" name="DOB" id="DOB" value="<?php echo $arrdata['dob'];?>" required>
                </div>
                <div class="form-item">
                    <label for="email">E-mail:</label>
                    <input type="email" name="email" id="email" placeholder="email@xyz.com" value="<?php echo $arrdata['email'];?>" required>
                </div>
                <div class="form-item">
                    <label for="year">Year:</label>
                    <select name="year" id="year" value="<?php echo $arrdata['year'];?>">
                        <option value=" 1st Year" >First Year</option>
                        <option value="2nd year">Second Year </option>
                        <option value="3rd year">Third Year</option>
                        <option value="4th year">Fourth Year</option>
                    </select>
                </div>
                <div class="form-item">
                    <label for="department">Department:</label>
                    <select name="department" id="department" value="<?php echo $arrdata['dept'];?>">
                        <option value="electrical">Electrical Engineering</option>
                        <option value="electrical">Computer Engineering</option>
                        <option value="electrical">Software Engineering</option>
                        <option value="electrical">Civil Engineering</option>
                    </select>
                </div>

                <div class="form-item">
                    <label for="phonenumber">Tel/Mobile:</label>
                    <input type="text" name="phonenumber" id="phonenumber" placeholder="XXX XXX XXXX" value="<?php echo $arrdata['mobile_no'];?>" required>
                </div>
                <div class="studentimage">
                    <label>Student Image:</label>
                    <input type="file" name="studentimage" id="studentimage" accept="image/png,image/jpg" value="<?php echo $arrdata['Image'];?>">
                    <center>
                        <div id="display_image">

                        </div>
                        <p>(less than 5 Mb)</p>
                    </center>    
                </div>
                <hr>
                <h3>Permanent Address</h3>
                <div class="form-item">
                    <label for="pstate">State:</label>
                    <input type="text" name="pstate" id="pstate" placeholder="State" value="<?php echo $arrdata['state'];?>" required>
                </div>
                <div class="form-item">
                    <label for="pcity">City:</label>
                    <input type="text" name="pcity" id="pcity" placeholder="City"  value="<?php echo $arrdata['city'];?>"required>
                </div>
                <div class="form-item">
                    <label for="pzip">Zip Code:</label>
                    <input type="number" name="pzip" id="pzip" placeholder="Zip Code"  value="<?php echo $arrdata['zipcode'];?>"required>
                </div>
                <div class="form-item">
                    <label for="pphonenumber">Tel/Mobile:</label>
                    <input type="text" name="pphonenumber" id="pphonenumber" placeholder="XXX XXX XXXX"  value="<?php echo $arrdata['mobile_no'];?>"required>
                </div>
                <hr> 

                <button class="register" type="submit" name="Register">Register</button>
               <li class="nav-item">
               <a href="http://localhost/Mini-Project/index.php/">
               <input  type="button" value="Back">
               </a>
               </li>
            </form>
        </div>

    </div>
 <script type="text/javascript">
    
    let pstate = document.querySelector("#pstate")
    let pcity = document.querySelector("#pcity")
    let pzip = document.querySelector("#pzip")
    let pphonenumber = document.querySelector("#pphonenumber")

    let tstate = document.querySelector("#tstate")
    let tcity = document.querySelector("#tcity")
    let tzip = document.querySelector("#tzip")
    let tphonenumber = document.querySelector("#tphonenumber")

    let sameaspermanent = document.querySelector("#sameaspermanent")
    sameaspermanent.addEventListener('change', () => {
            if (sameaspermanent.checked === true) {
                tstate.value = pstate.value;
                tcity.value = pcity.value;
                tzip.value = pzip.value;
                tphonenumber.value = pphonenumber.value;
            } else if (sameaspermanent.checked === false) {
                tstate.value = "";
                tcity.value = "";
                tzip.value = "";
                tphonenumber.value = "";
            }
        })



        const studentimage=document.querySelector("#studentimage");
        var uploaded_image="";
        studentimage.addEventListener("change",function(){
            const reader=new FileReader();
            reader.addEventListener("load",()=>{
                uploaded_image = reader.result;
                document.querySelector("#display_image").style.backgroudImage ='url($studentimage)'
            });
            reader.readAsDataURL(this.files[0]);
        })

 </script>
</body>

</html>

