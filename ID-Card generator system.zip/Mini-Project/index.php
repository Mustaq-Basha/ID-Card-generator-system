<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student database</title>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <?php include 'links.php' ?>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
<div class="p-5 bg-primary text-white text-center">
  <h1>Dayananda Sagar College of Engineering</h1>
  <p>(An Autonomus college,Affiliated to VTU-Belagavi)</p> 
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/Mini-Project/student-registration.php/" >Student</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/Mini-Project/idcard.php/">ID-Cards</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/Mini-Project/display.php/">Student Database</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href=" http://localhost/Mini-Project/login.php/"> Logout</a>
      </li>
    </ul>
  </div>  
</nav>

<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
      
      <div >
      </div>
      <p></p>
      <h3 class="mt-4">Some Links</h3>
      <p>................................................</p>
      <ul class="nav nav-pills flex-column">
        
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/Mini-Project/student-registration.php/">Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/Mini-Project/idcard.php/">Id-card</a>
        </li>
        <li class="nav-item">
          <a  class="nav-link" href="http://localhost/Mini-Project/display.php/">Student Data Base</a>
        </li>
      </ul>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Online ID card Generator</h2>
      <h5></h5>
      <p>The Online ID Card Generator System is easy to use and has a pleasant user interface. The system can be accessed only by a single user and requires him/her system credentials in order to manage and access the data and features
         of the project. This has CRUD Operations and Print Features for
     each module. The generated templates are both saved as an image for 
     printing and its HTML code for editing, and so as the generated ID Card.
</p>
      <p>Online ID CARD Generator System. This project is a web-based application that has the ability to create Identification Card Templates Dynamically and 
Generates ID Cards using the created templates. The system user can design the ID Card using the given options such as image file upload and text fields. He/She can also manage the positions of each text field and image. This system will help to create, store, print, retrieve ID Cards easily and hassle-free.
 </p>  

    </div>
  </div>
</div>

<div class="mt-5 p-4 bg-dark text-white text-center">
  <p>Footer</p>
</div>

</body>
</html>
<?php 
include 'connect.php';

?>