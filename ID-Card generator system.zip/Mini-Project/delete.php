<?php

include 'connect.php';
include 'links.php';

$id=$_GET['id'];
$deletequery="delete from student where id=$id ";

$query =mysqli_query($con,$deletequery);

header('location:http://localhost/Mini-Project/display.php/');
if($query){
    ?>
    <script>
        alert("Deletd Successfully");
     </script>  
     <?php 
}
else{
    ?>
    <script>
        alert("Not Deleted");
        </script>
      <?php  
}


?>