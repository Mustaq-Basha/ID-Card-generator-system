-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2022 at 04:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id_card_generator`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `m_name` varchar(30) NOT NULL,
  `gender` text NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(330) NOT NULL,
  `year` int(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `Image` text NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zipcode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `f_name`, `m_name`, `gender`, `dob`, `email`, `year`, `dept`, `mobile_no`, `Image`, `state`, `city`, `zipcode`) VALUES
(4, 'Mustaq Basha', 'Mahaboob Basha', 'Fajulunnisa', 'male', '2003-06-04', 'mustaqbasha@gmail.com', 2, 'electrical', '8106082500', 'download.png', 'Andhra Pradesh', 'kadapa', 516193),
(9, 'Shashank M R', 'RMC', 'RM', 'male', '2002-05-31', 'shashank@gmail.com', 2, 'electrical', '9972675366', 'download.png', 'Karnataka', 'Bangalore', 563125),
(10, 'Muskan', 'Mahaboob Basha', 'Fajulunnisa', 'female', '2005-10-05', 'mustaq@gmail.com', 1, 'electrical', '8106082500', 'download.png', 'Andhra Pradesh', 'Kadapa', 516193),
(11, 'Pavan Kalyan', 'MJT', 'MJR', 'male', '2003-11-05', 'Pavan_kalyan@gmail.com', 1, 'electrical', '8965723546', '', 'Andhra Pradesh', 'Vijayawada', 516983),
(18, 'kfbfbk', 'nfjkbf', 'jnkdgg', 'female', '2003-12-31', 'bbfkksdb@bhbi.com', 1, 'electrical', '6984269354', 'assets/img4.jpg', 'Andhra Pradesh', 'bggggg', 695831);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `fullname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `username`, `password`, `email`) VALUES
(4, 'Mustaq Basha', 'mustaq150', '12345', 'bkdffgf@gmail.com'),
(7, 'Mustaq Basha', 'mustaq', '123', 'mustaqbasha@gmail.co'),
(8, 'Shashank M R', 'shashank', '2002', 'shashank@gmail.com'),
(9, 'Rishab Shrama', 'Rishab100', '123', 'vignesh.mv47@gmail.c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
