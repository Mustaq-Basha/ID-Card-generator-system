<?php

?>

<!DOCTYPE html>
<html>
    <head>
      <?php include 'links.php';?>
      <style>
        table{
            border-collapse:collapse;
            background-color:#fff;
            box-shadow:0 10px 20px 0 rgba(0,0,0,0.3);
            border-radius:10px;
            margin:auto;
        }
        th,td{
            border:1px solid #f2f2f2;
            padding:8px 30px;
            text-align:center;
            color:grey;
        }
        th{
            text-transform: uppercase;
            font-weight: 500;
        }
        td{
            font-size:13px;
        }
        .fa-edit{ color:#63c76a;}
        .fa-trash{ color:#ff0000;}
      </style>
    </head>
    <body >
       <h1><center>Student List</center></h1>
       <center><div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Father Name</th>
                            <th>Mother Name</th>
                            <th>Gender</th>
                            <th>DOB</th>
                            <th>Email</th>
                            <th>Semester</th>
                            <th>Dept</th>
                            <th>Mobile</th>
                            <th>Image</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Zip code</th>
                            <th>Operation</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php

                        include 'connect.php';
                        $selectquery = "select * from student";

                        $query = mysqli_query($con,$selectquery);

                        $num =mysqli_num_rows($query);

                        $res =mysqli_fetch_array($query);

                        while($res =mysqli_fetch_array($query)){
                         ?>
                            <tr>
                            <td><?php echo $res['id'];?></td>
                            <td><?php echo $res['name'];?></td>
                            <td><?php echo $res['f_name'] ?></td>
                            <td><?php echo $res['m_name'] ?></td>
                            <td><?php echo $res['gender'] ?></td>
                            <td><?php echo $res['dob'] ?></td>
                            <td><?php echo $res['email'] ?></td>
                            <td><?php echo $res['year'] ?></td>
                            <td><?php echo $res['dept'] ?></td>
                            <td><?php echo $res['mobile_no'] ?></td>
                            <td><?php echo $res['Image'] ?></td>
                            <td><?php echo $res['state'] ?></td>
                            <td><?php echo $res['city'] ?></td>
                            <td><?php echo $res['zipcode'] ?></td>
                            <td><a href="http://localhost/Mini-Project/lik.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Print"><i class="fa-solid fa-print"></i></a></th>
                                           
                        </tr>
                          
                    <?php }

                    ?>
                        
                    </tbody>
                </table>
            </div>

       </div>
    </center>
    <script>
     $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
    </body>
</html>