
<?php
$img="back.jpeg"
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="idCard.css">
  
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
<style>
*{
    margin: 00px;
    padding: 00px;
    box-sizing: content-box;
}

.container {
    height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #e6ebe0;
    flex-direction: row;
    flex-flow: wrap;

}

.font{
    height: 375px;
    width: 250px;
    position: relative;
    border-radius: 10px;
}

.top{
    height: 30%;
    width: 100%;
    background-color: #8338ec;
    position: relative;
    z-index: 5;
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
}

.bottom{
    height: 70%;
    width: 100%;
    background-color: #8338ec;
    color: white;
    text-align: left;
    padding: 5px;
    line-height: 20px;
    font-size: 16px;
    text-align: center;
    margin-top: 20px;
    line-height: 22px;
}

.top img{
    height: 100px;
    width: 100px;
    background-color: #e6ebe0;
    border-radius: 10px;
    position: absolute;
    top:60px;
    left: 75px;
}
.bottom p{
    position: relative;
    top: 60px;
    text-align: center;
    text-transform: capitalize;
    font-weight: bold;
    font-size: 20px;
    
    
}
.bottom .desi{
    font-size:12px;
    color: grey;
    font-weight: normal;
}
.bottom .no{
    font-size: 15px;
    font-weight: normal;
}
.barcode img
{
    height: 65px;
    width: 65px;
    text-align: center;
    margin: 5px;
}
.barcode{
    text-align: center;
    position: relative;
    top: 70px;
}

.back
{
    height: 375px;
    width: 250px;
    border-radius: 10px;
    background-color: #8338ec;

}
.qr img{
    height: 80px;
    width: 100%;
    margin: 20px;
    background-color: white;
}
.Details {
    color: white;
    text-align: center;
    padding: 10px;
    font-size: 25px;
}


.details-info{
    color: white;
    text-align: left;
    padding: 5px;
    line-height: 20px;
    font-size: 16px;
    text-align: center;
    margin-top: 20px;
    line-height: 22px;
}

.logo {
    height: 40px;
    width: 150px;
    padding: 40px;
}

.logo img{
    height: 100%;
    width: 100%;
    color: white ;

}
.padding{
    padding-right: 20px;
}

@media screen and (max-width:400px)
{
    .container{
        height: 130vh;
    }
    .container .front{
        margin-top: 50px;
    }
}
@media screen and (max-width:600px)
{
    .container{
        height: 130vh;
    }
    .container .front{
        margin-top: 50px;
    }

}
    </style>

</head>
<body>
<?php

    include 'connect.php';
    if(isset($_GET['id'])){

        $id = $_GET['id'];
    
        $selectquery = "select * from student where id='$id'";
    
        $query = mysqli_query($con, $selectquery);
        if(mysqli_num_rows($query)>0)
            $res = mysqli_fetch_array($query);
    
    }

   
    ?>
                         
     <div class="container">
            <div class="padding">
                <div class="font">
                  <div class="top">
                    <h4><center>DAYANANDA SAGAR INSTITUTIONS</center></h4>
                    <h5><center>DAYANANDA SAGAR COLLEGE OF ENGINEERING</center></h5>
                           <p><center>(Atonomus & Affiliated with VTU)</center></p>
                        
                  </div>
                    <hr class="hr">
                    <div class="bottom">
                          
                    
                           <label>ID:</label><td><?php echo $res['id'];?></td><br></br>
                           <label>NAME:</label><td><?php echo $res['name'];?></td><br></br>
                           <label>YEAR:</label><td><?php echo $res['year'];?></td><br></br>
                           <label>DOB:</label><td><?php echo $res['dob'];?></td><br></br>
                           <label>DEPT:</label><td><?php echo $res['dept'];?></td><br></br>
                           <hr>
                    </div>
                </div>
            </div>
            <div class="back">
                <h4><center>DAYANANDA SAGAR INSTITUTIONS</center></h4>
                    <h5><center>DAYANANDA SAGAR COLLEGE OF ENGINEERING</center></h5>
                    <p><center>(Atonomus & Affiliated with VTU)<center></P>
                <h1 class="Details">Information</h1>
                <hr class="hr">
                <div class="details-info">

                    <label>FATHER NAME:</label><td><?php echo $res['f_name'];?></td><br></br>
                    <label>MOTHER NAME:</label><td><?php echo $res['m_name'];?></td><br></br>
                    <label>PHONE NO:</label><td><?php echo $res['mobile_no'];?></td><br></br>
                    <label>EMAIL:</label><td><?php echo $res['email'];?></td><br></br>                    
                    <hr>
                </div>
            </div>
        </div>
                          

                    ?>
        
        
</body>
</html>

