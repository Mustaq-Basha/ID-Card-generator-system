<?php

                    if(isset($_POST["submit"]))
                        {
                            include 'connect.php';

                            $str = $_POST["search"];
                            $searchquery ="select * from student where id =$str";
                            $qul =mysqli_query($con,$searchquery);
                          
                            while($res =mysqli_fetch_assoc($qul)){
                                ?>
                                <tr>
                                   <td><?php echo $res['id'];?></td>
                                   <td><?php echo $res['name'];?></td>
                                   <td><?php echo $res['f_name'] ?></td>
                                   <td><?php echo $res['m_name'] ?></td>
                                   <td><?php echo $res['gender'] ?></td>
                                   <td><?php echo $res['dob'] ?></td>
                                   <td><?php echo $res['email'] ?></td>
                                   <td><?php echo $res['year'] ?></td>
                                   <td><?php echo $res['dept'] ?></td>
                                   <td><?php echo $res['mobile_no'] ?></td>
                                   <td><img src="assets/<?php echo $res['Image'] ?>" height="100px" width="100px"></td>
                                   <td><?php echo $res['state'] ?></td>
                                   <td><?php echo $res['city'] ?></td>
                                   <td><?php echo $res['zipcode'] ?></td>
                                   <td><a href="http://localhost/Mini-Project/updates.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></th>
                                   <td><a href="http://localhost/Mini-Project/delete.php/?id=<?php echo $res['id'];?>" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></th>               
                               </tr>
                                 
                           <?php }

                            }
       
                           ?>